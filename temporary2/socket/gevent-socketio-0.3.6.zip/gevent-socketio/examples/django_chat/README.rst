
Installation
============

Steps to setup this example::

    $ cd examples/django_chat
    $ python bootstrap.py
    $ ./bin/buildout
    $ ./bin/django syncdb
    $ ./bin/django runserver_socketio
