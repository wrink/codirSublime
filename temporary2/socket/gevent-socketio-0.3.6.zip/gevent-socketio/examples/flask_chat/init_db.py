import chat
chat.init_db()

