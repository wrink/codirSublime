.. _gunicorn_module:

:mod:`socketio.sgunicorn`
=========================

.. automodule:: socketio.sgunicorn
    :members:
    :undoc-members:
    :show-inheritance:
