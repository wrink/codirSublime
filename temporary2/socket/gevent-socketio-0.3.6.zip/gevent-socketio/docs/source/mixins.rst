.. _mixins_module:

:mod:`socketio.mixins`
======================

.. automodule:: socketio.mixins

.. literalinclude:: ../../socketio/mixins.py
   :pyobject: BroadcastMixin

.. literalinclude:: ../../socketio/mixins.py
   :pyobject: RoomsMixin
