.. _handler_module:

:mod:`socketio.handler`
=======================

This is a lower-level transports handler. It is responsible for calling your WSGI application.

.. automodule:: socketio.handler
    :members:
    :undoc-members:
    :show-inheritance:
